﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.Threading;
//The purpose of this application: to do data comparison for two data set(table/view)
//Steps:1.source / target information: Fill in server name, user name, choose database and table/view, fill in filter condition if necessary
//2.Click "Edit Mapping" button, all source columns will be displayed and the target columns that have the same column name and data type, data length will be displayed at the right of source column
//3.Choose the columns we want to compare and identify key columns
//4.Click the "Compare" button, a source data set and a target data set that ordered by key columns will start to compare, display the rows with different values

namespace WindowsFormsApplication1
{
    public enum ConnType
    {
        Source = 0, // when ConnType=0, it is for source 
        Target = 1, // when ConnType=1, it is for target 
        Other = 99,
    }

    public partial class MainForm : Form
    {

        #region Global
        const string RETRIEVE_TABLES_SQL = "SELECT u.name + '.' + o.name as Name FROM SysObjects o, SysUsers u Where o.uid = u.uid AND o.XType IN ('U','V') ORDER BY o.XType,o.Name";//To list all user tables and views under current database
        const string RETRIEVE_DATABASES_SQL = "SELECT Name FROM Master..SysDatabases ORDER BY Name";//To list all database name under current selected server
        const string SRC_DBLIST_TABLE = "SrcDBList";
        const string TRG_DBLIST_TABLE = "TrgDBList";
        const string SRC_TABLIST_TABLE = "SrcTabList";
        const string TRG_TABLIST_TABLE = "TrgTabList";
        const string COL_NAME = "Name";
        const string TABLE = "Table";
        const string DB = "DB";

        SqlConnection[] connections = new SqlConnection[2];

        DataSet dsGlobal = new DataSet();
        DataTable dtResult = new DataTable("ResultTable");

        int columnCount = 0;
        bool[] diffColIndex = null;
        bool allDiff = false;

        List<Control> srcControls = new List<Control>();
        List<Control> trgControls = new List<Control>();
        List<Control> compControls = new List<Control>();

        int srcStatus = 0;
        int trgStatus = 0;

        bool refreshed = false;

        #endregion

        #region Constructor
        public MainForm()
        {
            InitializeComponent();
            CollectControls();
            SetLayout(ConnType.Source, 0);
            SetLayout(ConnType.Target, 0);
        }
        
        #endregion

        #region Database

        private DataTable ExecuteSQL(string sql, ConnType connType)
        {// execute the sql "SELECT Name FROM Master..SysDatabases ORDER BY Name"
            DataSet ds = new DataSet();
            ExecuteSQL(sql, connType, ds, "tmp");
            return ds.Tables[0]; 
        }

        private void ExecuteSQL(string sql, ConnType connType, DataSet ds, string tabname)
        {
            if (sql == null || sql.Length == 0 || connections[(int)connType] == null || connections[(int)connType].State != ConnectionState.Open || ds == null || tabname == null || tabname.Length == 0)
                return;

            if (ds.Tables.Contains(tabname))
                ds.Tables.Remove(tabname);

            SqlDataAdapter daSource = GetDataAdapter(sql, connType);
            daSource.Fill(ds, tabname);
        }

        private SqlDataAdapter GetDataAdapter(string sql, ConnType connType)
        {
            SqlCommand comm = new SqlCommand(sql, connections[(int)connType]);
            comm.CommandTimeout = 0;
            SqlDataAdapter da = new SqlDataAdapter(comm);
            return da;
        }

        private SqlDataReader GetDataReader(string sql, ConnType connType)
        {
            SqlCommand comm = new SqlCommand(sql, connections[(int)connType]);
            comm.CommandTimeout = 0;
            SqlDataReader dr = comm.ExecuteReader();
            return dr;
        }

        private void NewConnection(ConnType type, string connStr)
        {
            SqlConnection conn = connections[(int)type];//define a connection array, connections[0] is for source , connections[1] is for target
            if (conn != null && conn.State == ConnectionState.Open) // if the state of this connection is open, then close it
            {
                conn.Close();
            }
            conn = new SqlConnection(connStr); // new a connection
            connections[(int)type] = conn;
            try
            {
                conn.Open();//open the connection
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string BuildConnectionString(string server, bool isWinAuth, string username, string password, string database) 
        {// pass the parameters from input, server name, winauth, username, password
            string connStrServer = @"server=" + server.Trim();
            string connStrAuth = (isWinAuth) ? ";Integrated Security=SSPI;" : ";user id=" + username.Trim() + ";pwd=" + password.Trim();
            string connStrDB = (database == null) ? "" : ";database=" + database;
            return connStrServer + connStrAuth + connStrDB;
            // combine a string, for example @"server=" COTTONWOOD01, user id=  webapp ;pwd= webapp
        }

        private void CloseConnections()// close the connection
        {
            CloseConnection(ConnType.Source);
            CloseConnection(ConnType.Target);
        }

        private void CloseConnection(ConnType connType)
        {
            if (connections[(int)connType] != null && connections[(int)connType].State == ConnectionState.Open)
                connections[(int)connType].Close();
        }

        #endregion

        #region DataSet

        private int getTrgRowCount()
        {// get the row count for target table with filter contition
            string sql = "SELECT COUNT(1) FROM " + cb_TrgTab.SelectedValue + " WHERE " + (tb_TrgFilter.Text.Trim().Length == 0 ? "1=1" : tb_TrgFilter.Text.Trim());
            DataTable result = ExecuteSQL(sql, ConnType.Target);
            return (int)result.Rows[0][0];
        }

        private int getSrcRowCount()
        {// get the row count for source table with filter contition
            string sql = "SELECT COUNT(1) FROM " + cb_SrcTab.SelectedValue + " WHERE " + (tb_SrcFilter.Text.Trim().Length == 0 ? "1=1" : tb_SrcFilter.Text.Trim());
            DataTable result = ExecuteSQL(sql, ConnType.Source);
            return (int)result.Rows[0][0];
        }

        private void InsertRow(SqlDataReader left, SqlDataReader right)
        {//insert data to the compare result area
            DataRow newRow = dtResult.NewRow();
            for (int i = 0; i < columnCount; i++)
            {
                newRow[i] = (left == null) ? DBNull.Value : left[i];//if source is null, then set this cell is null, else fill in the source value
                if (left == null)//if source is null, then set diffColIndex[i]=true
                    diffColIndex[i] = true;
            }
            for (int i = 0; i < columnCount; i++)//if target is null, then set this cell is null, else fill in the target value
            {
                newRow[i + columnCount] = (right == null) ? DBNull.Value : right[i];
                if (right == null)//if target is null, then set target diffColIndex[]=true
                    diffColIndex[i + columnCount] = true;
            }
            dtResult.Rows.Add(newRow);
        }

        private void DataRowCompare(SqlDataReader left, SqlDataReader right)
        {// data compare
            // if source 
            bool diff = false;

            if (left == null || right == null)//compare the key values, if source is null or target is null, it means all different, just display the result
            {
                diff = true;//diff means the whole row is different
                if (!allDiff)//the default value of allDiff is false, if it still is false, add it to ArrayList
                {
                    ArrayList.Repeat(true, diffColIndex.Length).CopyTo(diffColIndex);
                    allDiff = true;
                }
            }
            else
            { // the key values of source and target are equal, then compare other columns
                for (int i = 0; i < columnCount; i++)
                {
                    if (string.Compare(left[i].ToString(), right[i].ToString()) != 0)//if two columns are not equal
                    {
                        diff = true;
                        diffColIndex[i] = true;// if the column is different set diffColIndex=true for source column
                        diffColIndex[i + columnCount] = true;// if the column is different set diffColIndex=true for target column
                    }
                }
            }

            if (diff)
            {
                InsertRow(left, right);//just insert the row has different, insert the result to compare result area, one by one
            }
        }

        private void MappingColumns(DataSet ds, string src, string trg)
        {  //if source column has the same target column name and type is the same, then display the same line
            //else display all other not matched source columns on the source column

            DataTable mapping = new DataTable("Mapping");
            // define the column name for this source/target mapping area
            mapping.Columns.Add("Selected", System.Type.GetType("System.Boolean"));// it is a boolean column, to identify it will be used to compare or not
            mapping.Columns.Add("SourceColumns", ds.Tables[src].Columns["name"].DataType);// source table's column name
            mapping.Columns.Add("TargetColumns", ds.Tables[trg].Columns["name"].DataType);// target table's column name
            mapping.Columns.Add("Keys", System.Type.GetType("System.Boolean"));// it is a boolean column, to identify it is a key column or not
            ds.Tables.Add(mapping);
            DataRelation dr = new DataRelation("ColumnName", ds.Tables[src].Columns["name"], ds.Tables[trg].Columns["name"], false);
            // create relationship for the two data set, source column name and target column name
            ds.Relations.Add(dr);

            mapping.BeginLoadData();
            foreach (DataRow row in ds.Tables[src].Rows) //traversal all source columns
            { 
                DataRow newRow = mapping.NewRow();
                newRow[0] = false;// the selected column
                newRow[1] = row["name"];//the source column
                newRow[3] = false;// the key column

                foreach (DataRow childRow in row.GetChildRows(dr))
                {
                    if (childRow != null)//if there are mapped columns on the target
                    {
                        newRow[2] = childRow["name"];//pass the mapped column to target column and set the selected column to true
                        newRow[0] = true;
                    }
                }
                mapping.Rows.Add(newRow);
                dgv_Mappings.Rows.Add(newRow[0], newRow[1], newRow[2], newRow[3]);// at last, all source column names will be displayed, but not all target column name will be displayed
                //but the target column names can be updated by user
            }

            mapping.EndLoadData();

        }

        private int CompareKeys(SqlDataReader drLeft, SqlDataReader drRight, int[] keyIndex)
        {
            if (drLeft == null)// if the source data set is null, then return 1, it means just display all target data set on the compare result area
                return 1;

            if (drRight == null)// if the target data set is null, then return -1, it means just display all source data set on the compare result area
                return -1;

            foreach (int i in keyIndex)// loop compare for each key column
            {
                if (string.Compare(drLeft[i].ToString(), drRight[i].ToString().Substring(2)) == 0) //if the the key value are equal
                    // why here need Substring(2)?
                    //String.Compare函数就是比较两个字符串，逐个比较每个字符的ASCII码值，如果当前对应的A串中的字符小于B串，那么代表A串小于B串，返回-1，否则A串大于B串，返回1，如果比较完毕后全部都相等，那么则认为A串与B串相等，返回0，
                    continue;
                else
                    return string.Compare(drLeft[i].ToString(), drRight[i].ToString().Substring(2));//return 1 or -1
            }
            return 0;
        }

        private void BuildSql(ref string sqlSrc, ref string sqlTrg, ref int[] keyIndex, ref string sqlColSrc, ref string sqlColTrg)
        {// build sql for source: select column name from table where filter order by key
            //build 4 sqls, sqlColSrc is to display the column name, sqlSrc is to get the sql with filter and order by
            List<int> lstKeysIndex = new List<int>();
            sqlSrc = "";
            sqlTrg = "";
            sqlSrc += "SELECT ";
            sqlTrg += "SELECT ";
            string sqlSrcOrder = " ORDER BY ";
            string sqlTrgOrder = " ORDER BY ";
            string srcCol = "";
            string trgCol = "";

            int selectIndex = 0;
            // get the selected column name from dgv_Mappings
            foreach (DataGridViewRow row in dgv_Mappings.Rows)
            {
                if ((bool)row.Cells[0].Value != true) // cell[0] =true, it means it is selected
                    continue;                
                srcCol = ((string)row.Cells[1].Value).Split('[')[0].Trim();// get the column name and remove the column type from id[varchar(10)]
                trgCol = ((string)row.Cells[2].Value).Split('[')[0].Trim();
                sqlSrc += srcCol + ", ";// combine all selected source column names
                sqlTrg += trgCol + ", ";

                if ((bool)row.Cells[3].Value == true)//Cells[3]= true, it means it is a key column, we will use it to order by
                {
                    lstKeysIndex.Add(selectIndex);
                    sqlSrcOrder += srcCol + ", "; // combine all key columns
                    sqlTrgOrder += trgCol + ", ";
                }
                selectIndex++;

            }
            sqlSrc = sqlSrc.Remove(sqlSrc.Length - 2);// remove the ", " from the combined string
            sqlTrg = sqlTrg.Remove(sqlTrg.Length - 2);
            sqlSrcOrder = sqlSrcOrder.Remove(sqlSrcOrder.Length - 2);
            sqlTrgOrder = sqlTrgOrder.Remove(sqlTrgOrder.Length - 2);

            sqlSrc += " FROM " + cb_SrcTab.SelectedValue;
            sqlTrg += " FROM " + cb_TrgTab.SelectedValue;

            sqlColSrc = sqlSrc + " WHERE 1=2"; // this sql will be executed without return any data forever, just get the column name
            sqlColTrg = sqlTrg + " WHERE 1=2";

            sqlSrc += " WHERE " + (tb_SrcFilter.Text.Trim().Length == 0 ? "1=1" : tb_SrcFilter.Text.Trim()) + sqlSrcOrder; // it is has filter, then add filter
            sqlTrg += " WHERE " + (tb_TrgFilter.Text.Trim().Length == 0 ? "1=1" : tb_TrgFilter.Text.Trim()) + sqlTrgOrder;

            keyIndex = lstKeysIndex.ToArray();
        }

        private void HighlightCells()
        {
            DataGridViewCellStyle highlight = new DataGridViewCellStyle();
            highlight.ForeColor = Color.Red;

            int colCount = dataGridView1.ColumnCount;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                for (int i = 0; i < colCount / 2; i++)
                {
                    if (row.Cells[0].Value == null)
                    {// if source key is null but target keys exist,it means couldn't find the source, mark this row to green 
                        row.Cells[i].Style.BackColor = Color.LightGreen;
                        continue;
                    }
                    if (row.Cells[colCount / 2].Value == null)
                    {
                        row.Cells[colCount / 2 + i].Style.BackColor = Color.LightGreen;
                        continue;
                    }
                    if ((row.Cells[i].Value == null && row.Cells[colCount / 2 + i].Value != null) || (row.Cells[i].Value != null && !row.Cells[i].Value.Equals(row.Cells[colCount / 2 + i].Value)))
                    {//if (source value is null and target value is not null ) or (source value is not null and target value is not equal to source value )
                        row.Cells[i].Style.BackColor = Color.LightPink;//fill color for source column
                        row.Cells[colCount / 2 + i].Style.BackColor = Color.LightPink;//fill color for target column
                    }
                    //if source value is equal to target value, not fill color
                }
            }
        }

        private void Reset()
        {
            columnCount = 0;
            diffColIndex = null;
            allDiff = false;
            dsGlobal.Tables.Clear();
            cb_DiffCols.Checked = false;
        }

        #endregion

        #region Form

        public void AutoSizeComboBoxItem(object sender)
        {
            if (sender is ComboBox)
            {
                Graphics grap = Graphics.FromHwnd((sender as ComboBox).Handle);
                grap.PageUnit = GraphicsUnit.Pixel;
                StringFormat sf = new StringFormat(StringFormat.GenericTypographic);
                SizeF size;
                int i = 0;
                int extraWidth = 5;
                bool resize = false;
                float maxSize = 0f;
                if ((sender as ComboBox).MaxDropDownItems < (sender as ComboBox).Items.Count)
                {
                    extraWidth += 18;
                }

                while (i < (sender as ComboBox).Items.Count)
                {
                    DataRowView tmpRow = (DataRowView)(sender as ComboBox).Items[i];
                    string test = (string)tmpRow["Name"];

                    size = grap.MeasureString(test, (sender as ComboBox).Font, 500, sf);
                    maxSize = Math.Max(size.Width, maxSize);
                    if (size.Width > (sender as ComboBox).DropDownWidth - extraWidth)
                    {
                        (sender as ComboBox).DropDownWidth = System.Convert.ToInt32(size.Width) + extraWidth;
                        resize = true;

                    }

                    i++;

                }
                if (!resize)
                {
                    (sender as ComboBox).DropDownWidth = (int)maxSize + extraWidth;

                }

                grap.Dispose();
                sf.Dispose();
            }

        }

        private void CollectControls()
        {
            srcControls.Add(tb_SrcServer);
            srcControls.Add(cb_SrcWinAuth);
            srcControls.Add(tb_SrcUname);
            srcControls.Add(tb_SrcPwd);
            srcControls.Add(cb_SrcDB);
            srcControls.Add(bt_SrcRfs);
            srcControls.Add(cb_SrcTab);
            srcControls.Add(bt_SrcRfst);
            srcControls.Add(tb_SrcFilter);

            trgControls.Add(tb_TrgServer);
            trgControls.Add(cb_TrgWinAuth);
            trgControls.Add(tb_TrgUname);
            trgControls.Add(tb_TrgPwd);
            trgControls.Add(cb_TrgDB);
            trgControls.Add(bt_TrgRfs);
            trgControls.Add(cb_TrgTab);
            trgControls.Add(bt_TrgRfst);
            trgControls.Add(tb_TrgFilter);

            compControls.Add(bt_EditMapping);
            compControls.Add(bt_Compare);
            compControls.Add(cb_DiffCols);
        }

        private void SetLayout(ConnType connType, int status)
        {
            List<Control> oper = null;

            if (connType == ConnType.Source)
            {
                oper = srcControls;
                srcStatus = status;
            }
            else if (connType == ConnType.Target)
            {
                oper = trgControls;
                trgStatus = status;
            }
            else
            {
                oper = compControls;
            }

            switch (status)
            {
                case 0:
                    oper[0].Enabled = true;
                    oper[1].Enabled = true;
                    oper[2].Enabled = !((CheckBox)oper[1]).Checked;
                    oper[3].Enabled = !((CheckBox)oper[1]).Checked;
                    oper[4].Enabled = false;
                    oper[5].Enabled = true;
                    oper[6].Enabled = false;
                    oper[7].Enabled = false;
                    oper[8].Enabled = false;
                    break;
                case 1:
                    oper[0].Enabled = false;
                    oper[1].Enabled = false;
                    oper[2].Enabled = false;
                    oper[3].Enabled = false;
                    oper[4].Enabled = true;
                    oper[5].Enabled = true;
                    oper[6].Enabled = false;
                    oper[7].Enabled = true;
                    oper[8].Enabled = false;
                    break;
                case 2:
                    oper[0].Enabled = false;
                    oper[1].Enabled = false;
                    oper[2].Enabled = false;
                    oper[3].Enabled = false;
                    oper[4].Enabled = false;
                    oper[5].Enabled = false;
                    oper[6].Enabled = true;
                    oper[7].Enabled = true;
                    oper[8].Enabled = true;
                    compControls[1].Enabled = false;
                    compControls[2].Enabled = false;
                    break;
                case 5:
                    oper[1].Enabled = true;
                    srcControls[6].Enabled = false;
                    srcControls[7].Enabled = false;
                    srcControls[8].Enabled = false;
                    trgControls[6].Enabled = false;
                    trgControls[7].Enabled = false;
                    trgControls[8].Enabled = false;
                    break;
                case 6:
                    oper[2].Enabled = true;
                    break;
                default:
                    break;
            }

            if (srcStatus == 2 && trgStatus == 2)
            {
                compControls[0].Enabled = true;
            }
            else
            {
                compControls[0].Enabled = false;
            }
        }

        private void BindDataSource(ComboBox comboBoxBind, ConnType connType, string type)
        {
            string target_table = "";
            string sql = (type == DB) ? RETRIEVE_DATABASES_SQL : RETRIEVE_TABLES_SQL;// if type is DB then get a list of database name, if not then get a list of table name
            //here if type =DB, sql= "SELECT Name FROM Master..SysDatabases ORDER BY Name"
            if (connType == ConnType.Source)
            {
                target_table = (type == DB) ? SRC_DBLIST_TABLE : SRC_TABLIST_TABLE; // for source connction, if type is DB then get a list of database name
            }
            else if (connType == ConnType.Target)
            {
                target_table = (type == DB) ? TRG_DBLIST_TABLE : TRG_TABLIST_TABLE;
            }
            ExecuteSQL(sql, connType, dsGlobal, target_table);
            comboBoxBind.DisplayMember = COL_NAME;
            comboBoxBind.ValueMember = COL_NAME;

            comboBoxBind.DataSource = dsGlobal.Tables[target_table];
        }

        private void DoRefresh()
        {
            while (true)
            {
                Thread.Sleep(1000);
                refreshed = false;
            }
        }

        #endregion

        #region Event

        private void cb_SrcWinAuth_CheckedChanged(object sender, EventArgs e)
        {
            SetLayout(ConnType.Source, 0);
        }

        private void cb_TrgWinAuth_CheckedChanged(object sender, EventArgs e)
        {
            SetLayout(ConnType.Target, 0);
        }

        private void bt_SrcRfs_Click(object sender, EventArgs e)
        {  //Click the button on the right of database combine box, connect to server, list all database name             
            try
            {
                if (cb_SrcDB.DataSource == null)//if the database dropdown list is null
                {
                    string connStr = BuildConnectionString(tb_SrcServer.Text, cb_SrcWinAuth.Checked, tb_SrcUname.Text, tb_SrcPwd.Text, null);
                    // combine a string, for example @"server=" COTTONWOOD01, user id=  webapp ;pwd= webapp
                    NewConnection(ConnType.Source, connStr);//create a new connection

                    BindDataSource(cb_SrcDB, ConnType.Source, DB);// get a list of database name and show on the combine box

                    SetLayout(ConnType.Source, 1);
                }
                else
                {
                    cb_SrcDB.DataSource = null;
                    SetLayout(ConnType.Source, 0);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bt_TrgRfs_Click(object sender, EventArgs e)
        {
            try
            {
                if (cb_TrgDB.DataSource == null)
                {
                    string connStr = BuildConnectionString(tb_TrgServer.Text, cb_TrgWinAuth.Checked, tb_TrgUname.Text, tb_TrgPwd.Text, null);
                    NewConnection(ConnType.Target, connStr);
                    BindDataSource(cb_TrgDB, ConnType.Target, DB);
                    SetLayout(ConnType.Target, 1);
                }
                else
                {
                    cb_TrgDB.DataSource = null;
                    SetLayout(ConnType.Target, 0);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void bt_SrcRfst_Click(object sender, EventArgs e)
        {
            if (cb_SrcTab.DataSource == null)
            {

                try
                {
                    string connStr = BuildConnectionString(tb_SrcServer.Text, cb_SrcWinAuth.Checked, tb_SrcUname.Text, tb_SrcPwd.Text, (string)cb_SrcDB.SelectedValue);
                    //pass parameter from input and combine a string, expecially for the database selected on the database dropdown list
                    NewConnection(ConnType.Source, connStr);// create a connection for this database

                    BindDataSource(cb_SrcTab, ConnType.Source, TABLE);// get a list of table name and display on the table/view dropdown list
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                SetLayout(ConnType.Source, 2);

            }
            else
            {
                cb_SrcTab.DataSource = null;
                SetLayout(ConnType.Source, 1);
            }
        }

        private void bt_TrgRfst_Click(object sender, EventArgs e)
        {
            if (cb_TrgTab.DataSource == null)
            {

                try
                {
                    string connStr = BuildConnectionString(tb_TrgServer.Text, cb_TrgWinAuth.Checked, tb_TrgUname.Text, tb_TrgPwd.Text, (string)cb_TrgDB.SelectedValue);
                    NewConnection(ConnType.Target, connStr);

                    BindDataSource(cb_TrgTab, ConnType.Target, TABLE);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                SetLayout(ConnType.Target, 2);
            }
            else
            {
                cb_TrgTab.DataSource = null;
                SetLayout(ConnType.Target, 1);
            }
        }      

        private void bt_EditMapping_Click(object sender, EventArgs e)
        {
            if (bt_EditMapping.Text == "Edit Mapping")
            {
                dgv_Mappings.Rows.Clear();// clear the area that at the right of "Edit Mapping"

                string sqlSrc = "SELECT c.name + ' [' + t.name + '(' + cast(c.length as varchar) + ')]' AS Name FROM SysColumns c, SysTypes t  WHERE c.xtype = t.xtype AND c.id = OBJECT_ID('" + cb_SrcTab.SelectedValue + "')";
                // Display the column name, column type for the selected table, sqlSrc="SELECT c.name[t.name] as Name From SysColumns c, SysTypes t  WHERE c.xtype = t.xtype AND c.id = OBJECT_ID(HR)"
                string sqlTrg = "SELECT c.name + ' [' + t.name + '(' + cast(c.length as varchar) + ')]' AS Name FROM SysColumns c, SysTypes t  WHERE c.xtype = t.xtype AND c.id = OBJECT_ID('" + cb_TrgTab.SelectedValue + "')";

                DataSet ds = new DataSet();

                ExecuteSQL(sqlSrc, ConnType.Source, ds, "SrcCols");
                ExecuteSQL(sqlTrg, ConnType.Target, ds, "TrgCols");
                // dgv_Mappings is a array, array[0] is selected, array[1] is source columns, array[2] is target columns, array[3] is the key columns
                ((DataGridViewComboBoxColumn)dgv_Mappings.Columns[2]).DataSource = ds.Tables["TrgCols"];// here just display the target columns, and we will identify if the source column can be displayed at the same line as target column
                ((DataGridViewComboBoxColumn)dgv_Mappings.Columns[2]).DisplayMember = "name";
                ((DataGridViewComboBoxColumn)dgv_Mappings.Columns[2]).ValueMember = "name";

                MappingColumns(ds, "SrcCols", "TrgCols");
                //if source column has the same target column name and type is the same, then display the same line
                //else display all other not matched source columns on the source column

                dgv_Mappings.Refresh();
                // refresh the Source/Target mapping area
                SetLayout(ConnType.Other, 5);

                bt_EditMapping.Text = "Update Source/Target";
            }
            else
            {
                dgv_Mappings.Rows.Clear();
                if (dataGridView1.Rows.Count > 0)
                    dataGridView1.Rows.Clear();
                SetLayout(ConnType.Source, 2);
                SetLayout(ConnType.Target, 2);
                bt_EditMapping.Text = "Edit Mapping";
            }
            
        }

        private void bt_Compare_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            if (!ValidateColumnMapping())//check if there is no selected column or no key column, pop up error message directly
            {
                MessageBox.Show("Invalid or incompleted column mapping.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Reset();//if click compare button more than one time, reset all parameters

            dtResult = new DataTable("ResultTable");

            string sqlSource = "";
            string sqlTarget = "";

            string sqlColSource = "";
            string sqlColTarget = "";

            int[] keyIndex = null;

            BuildSql(ref sqlSource, ref sqlTarget, ref keyIndex, ref sqlColSource, ref sqlColTarget);
            // The ref keyword causes an argument to be passed by reference, not by value. The effect of passing by reference is that any change to the parameter in the method is reflected in the underlying argument variable in the calling method. The value of a reference parameter is always the same as the value of the underlying argument variable. 
            int srcRowCount = 0;
            int trgRowCount = 0;

            try
            {
                srcRowCount = getSrcRowCount();
                trgRowCount = getTrgRowCount();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);              
                return;
            }

            DataTable dtSource = ExecuteSQL(sqlColSource, ConnType.Source); //execute the source sql
            DataTable dtTarget = ExecuteSQL(sqlColTarget, ConnType.Target);

            SqlDataReader drSource = GetDataReader(sqlSource, ConnType.Source);// get a list of source data that has been order by key column
            SqlDataReader drTarget = GetDataReader(sqlTarget, ConnType.Target);// get a list of target data that has been order by key column

            foreach (DataGridViewRow row in dgv_Mappings.Rows)
            { //add src.column name to the compare result area, here need to pass the type of the column
                if ((bool)row.Cells[0].Value != true)
                    continue;

                dtResult.Columns.Add("src." + ((string)row.Cells[1].Value).Split('[')[0].Trim(), dtSource.Columns[((string)row.Cells[1].Value).Split('[')[0].Trim()].DataType);
                columnCount++;
            }

            foreach (DataGridViewRow row in dgv_Mappings.Rows)
            {//add trg.column name to the compare result area, here need to pass the type of the column
                if ((bool)row.Cells[0].Value != true)
                    continue;

                dtResult.Columns.Add("trg." + ((string)row.Cells[2].Value).Split('[')[0].Trim(), dtTarget.Columns[((string)row.Cells[2].Value).Split('[')[0].Trim()].DataType);
            }

            bool isNotSrcEof = true;
            bool isNotTrgEof = true;

            diffColIndex = new bool[dtResult.Columns.Count];// note when the column has different vlaue, set it true, it will be used to "show different columns only"

            ProgressBarFrom fm = new ProgressBarFrom(0, srcRowCount, 0, trgRowCount);

            fm.Show(this);//show the progree bar

            dtResult.Clear();
            dtResult.BeginLoadData();

            isNotSrcEof = drSource.Read(); //drSource is the source data set
            isNotTrgEof = drTarget.Read();

            int processedCountSrc = 0; // to display the process bar
            int processedCountTrg = 0;

            Thread th = new Thread(new ThreadStart(this.DoRefresh)); 
            th.Start();// start the thread

            while (isNotSrcEof || isNotTrgEof) // if it is not the end line of source data set or not the end line of target data set
            {

                int flag = CompareKeys(isNotSrcEof ? drSource : null, isNotTrgEof ? drTarget : null, keyIndex);
                //1,the value on source is larger than the data on target
               // -1,the value on source is less than the data on target
                // 0,the value on source is equal to the data on target

                DataRowCompare((flag <= 0) ? drSource : null, (flag >= 0) ? drTarget : null);//data compare each row

                if (flag <= 0)
                {
                    isNotSrcEof = drSource.Read();// get the next row on source data set
                    processedCountSrc++;// add one to the processedCountSrc value
                }

                if (flag >= 0)
                {
                    isNotTrgEof = drTarget.Read();// get the next row on target data set
                    processedCountTrg++;
                }

                if (!refreshed)
                {//refresh action will be trigger every 1 second
                    //when refreshed = true,  it time to trigger the refresh action
                    //else wait the time until 1 second
                    fm.setPosSrc(processedCountSrc);
                    fm.setPosTrg(processedCountTrg);
                    refreshed = true;
                }

                if (fm.Cancelled)
                {//if click the cancel button on the form, the process bar thread should be abort, and stop to load data, close the conntion for drSource and drTarget
                    th.Abort();
                    dtResult.EndLoadData();
                    drSource.Close();
                    drTarget.Close();
                    return;
                }
            }

            th.Abort();

            fm.setPosSrc(processedCountSrc);
            fm.setPosTrg(processedCountTrg);

            dtResult.EndLoadData();
            drSource.Close();
            drTarget.Close();

            //Set key column always visiable
            foreach (int i in keyIndex)
            {
                diffColIndex[i] = true; //diffColIndex[i] is be used to "show different columns only", here set the diffColIndex[i] of key columns is true
                diffColIndex[i + columnCount] = true;// for target key columns
            }

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = dtResult;
            dataGridView1.Refresh();
            HighlightCells();//fill color for the missing rows/ additional rows/different cells

            this.Cursor = Cursors.Default;
            SetLayout(ConnType.Other, 6);

        }

        private bool ValidateColumnMapping()
        {
            int keyCount = 0;
            foreach (DataGridViewRow row in dgv_Mappings.Rows)
            {
                if ((bool)row.Cells[3].Value == true && (bool)row.Cells[0].Value == false)// it is a key column but not selected, false
                    return false;

                if ((bool)row.Cells[3].Value == true){
                    if ((bool)row.Cells[0].Value == false)
                        return false;
                    keyCount++;// if it is a key column and it is selected, count it as a key
                }

                if ((bool)row.Cells[0].Value == true &&
                    (row.Cells[1].Value.ToString().Trim() == "" || row.Cells[2].Value.ToString().Trim() == ""))
                    return false;
            }

            if (keyCount == 0)
                return false;

            return true;
        }

        private void cb_DiffCols_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_DiffCols.Checked) // just display the columns with different value, if this checkbox is selected
            {
                for (int i = 0; i < diffColIndex.Length; i++)//loop for all source columns
                {
                    dataGridView1.Columns[i].Visible = diffColIndex[i];//diffColIndex[i] is be used to "show different columns only", if diffColIndex[i]=true, then set Visible=true, means this column should be displayed
                    //else diffColIndex[i]=false, this column will be hidden
                }
            }
            else
            {
                foreach (DataGridViewColumn col in dataGridView1.Columns)
                {
                    col.Visible = true;// all columns that are selected to compare will be displayed
                }
            }

        }

        private void cb_TrgTab_DropDown(object sender, EventArgs e)
        {
            AutoSizeComboBoxItem(sender);
        }

        private void cb_SrcTab_DropDown(object sender, EventArgs e)
        {
            AutoSizeComboBoxItem(sender);
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            CloseConnections();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            dgv_Mappings.Width = this.Width - 417;
            dataGridView1.Width = this.Width - 59;
            dataGridView1.Height = this.Height - 333;
        }

        #endregion

        private void a(object sender, EventArgs e)
        {

        }

       
    }
}
